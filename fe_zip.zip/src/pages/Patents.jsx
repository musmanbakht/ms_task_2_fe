import React, { useEffect } from "react";
import PatentsTable from "../components/Tables.jsx/PatentsTable";
import { useState } from "react";
import PatentsBarChart from "../components/Charts/Patents/PatentsBarChart";
import { getPatentsStats } from "../API";
import PatentsCountryMap from "../components/Maps/PatentsCountryMap";
import PatentsBySchoolSkeleton from "../components/Charts/Patents/PatentsBarChartSkeleton";
const Patents = () => {
  const [patentsData, setPatentsData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [selectedSchool, setSelectedSchool] = useState(null);

  useEffect(() => {
    const PatentStats = async () => {
      try {
        setLoading(true);
        const response = await getPatentsStats(selectedSchool);
        setPatentsData(response.data || null);
      } catch (err) {
        console.log("Failed to fetch Data:", err);
      } finally {
        setLoading(false);
      }
    };
    PatentStats();
  }, [selectedSchool]);
  const handleBarClick = (schoolId, schoolName) => {
    setSelectedSchool(schoolId);
  };
  return (
    <>
      <div className="flex flex-wrap mt-2">
        <div className="w-full xl:w-4/12 mb-12 xl:mb-0 pl-4">
          {loading ? (
            <PatentsBySchoolSkeleton />
          ) : (
            <PatentsBarChart
              allPatents={patentsData ? patentsData?.patentsBySchool : []}
              onBarClick={handleBarClick}
              highlightDepartment={selectedSchool}
            />
          )}
        </div>
        <div className="w-full xl:w-8/12 px-4">
          {loading ? (
            <div className="h-[455px] w-full flex items-center justify-center bg-gray-100 rounded shadow animate-pulse">
              <span className="text-gray-500">Loading map...</span>
            </div>
          ) : (
            patentsData && (
              <PatentsCountryMap data={patentsData?.patentsByCountry || []} />
            )
          )}
        </div>
      </div>
      <PatentsTable />
    </>
  );
};

export default Patents;
